<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('css/admin/index.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<div style="max-width: 500px;">
<form action="<?php echo e(route('update_cat', ['cat_id' => $category->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Đổi tên chuyên mục</strong>
                <input type="text" value="<?php echo e($category->name); ?>" name="name" class="form-control" placeholder="Phần cứng, phần mềm, kỹ năng, pan bệnh,...">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Đổi chuyên mục cha</strong>
                <select name="category_id" class="form-control" >
                    <option value="" selected>Không thể chuyển đổi</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cat->id == $category->category_id): ?>
                            <option value="<?php echo e($cat->id); ?>" selected><?php echo e($cat->name); ?></option>
                        <?php else: ?>
                            
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Cập nhật chuyên mục</button>
        </div>
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog/resources/views/admin/categories/edit.blade.php ENDPATH**/ ?>