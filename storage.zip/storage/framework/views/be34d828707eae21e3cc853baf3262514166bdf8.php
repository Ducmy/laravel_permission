<?php $__env->startPush('js'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.js"></script>
 <!-- <script src="<?php echo e(asset('js/sort.js')); ?>"></script> -->
<?php $__env->stopPush(); ?>
<?php $__env->startPush('css'); ?>
<link href="https://code.jquery.com/ui/1.11.3/themes/smoothness/jquery-ui.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.css"/>
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
<link href="<?php echo e(asset('css/admin/index.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h3>Quản lý khóa học</h3>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('courses.index')); ?>"> Back</a>
        </div>
    </div>
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>

<form action="<?php echo e(route('courses.update',$course->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Tiêu đề:</strong>
                <input type="text" name="title" value="<?php echo e($course->title); ?>" class="form-control" placeholder="Name">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Mô tả:</strong>
                <textarea class="form-control" style="height:150px" name="summary" placeholder="Detail"><?php echo e($course->summary); ?></textarea>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Giáo viên:</strong>
                <select name="teacher_id" id="teacher" class="form-control" >
                        <option value="1">Admin</option>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($teacher->id == $course->teacher_id): ?>
                            <option value="<?php echo e($teacher->id); ?>" selected><?php echo e($teacher->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Chuyên mục:</strong>
                <select name="cat_id" id="cat_id" class="form-control" >
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cat->id == $course->cat_id): ?>
                            <option value="<?php echo e($cat->id); ?>" selected><?php echo e($cat->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Giá:</strong>
                <input type="text" name="price" value="<?php echo e($course->price); ?>" class="form-control" placeholder="Credit">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Cập nhật thông tin khóa học</button>
        </div>
    </div>
</form>
<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="alert alert-warning">Drag and drop để sắp xếp bài học!</div> 
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <table id="table" class="table table-bordered">
            <thead>
                <tr>
                  <th>No.</th>
                  <th>Tên bài học</th>
                  <th>Thao tác</th>
                </tr>
              </thead>
            <tbody id="tablecontents">
                <?php $index = 0;?>
                <?php $__currentLoopData = $ddcourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ddcourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($ddcourse->course_id == $course->id): ?>
                    <?php $index++;?>
                <tr class="row1" data-id="<?php echo e($ddcourse->id); ?>">
                    <td class=""><?php echo e($index); ?></td>
                    <td><a href="<?php echo e(route('ddcourses.show',$ddcourse->id)); ?>" target="_blank"><?php echo e($ddcourse->dd_title); ?></a></td>
                    <td class="">
                        <form action="<?php echo e(route('ddcourses.destroy',$ddcourse->id)); ?>" method="POST">
                            
                            <a href="<?php echo e(route('ddcourses.edit',$ddcourse->id)); ?>" class="btn btn-success ml-3">Sửa</a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Xóa</button>
                        </form>
                    </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<script type="text/javascript">
      $(function () {
        // $("#table").DataTable();

        $( "#tablecontents" ).sortable({
          items: "tr",
          cursor: 'move',
          opacity: 0.6,
          update: function() {
              sendOrderToServer();
          }
        });

        function sendOrderToServer() {
          var order = [];
          var token = $('meta[name="csrf-token"]').attr('content');
          $('tr.row1').each(function(index,element) {
            order.push({
              id: $(this).attr('data-id'),
              position: index+1
            });
          });

          $.ajax({
            type: "POST", 
            dataType: "json", 
            url: "<?php echo e(url('post-sortable')); ?>",
                data: {
              order: order,
              _token: token
            },
            success: function(response) {
                if (response.status == "success") {
                  console.log(response);
                } else {
                  console.log(response);
                }
            }
          });
        }
      });
    </script>
<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <a class="btn btn-success" href="<?php echo e(route('ddcourses.create', ['course_id' => $course->id])); ?>">Tạo bài học mới</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog/resources/views/admin/courses/edit.blade.php ENDPATH**/ ?>