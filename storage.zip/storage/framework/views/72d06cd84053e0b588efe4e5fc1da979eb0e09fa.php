 <?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('css/top/index.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?> <?php $__env->startSection('content'); ?>

<div id="wrap">

    <section class="banner-top">
        <div class="tim-kiem-khoa-hoc">
            <form action="/" method="get" class="form-search-course">
                <div class="form-group">
                    <input type="text" name="filter[title]" class="form-control" placeholder="Tìm khóa học" />
                </div>
                <button type="submit" class="btn btn-primary">Tìm kiếm</button>
            </form>
        </div>
    </section>
    <section class="introduce p-5">
        <div class="container">
            <div class="row">
                <div class="col-6">
                    <h4 class="text-danger text-center">
                        Giới thiệu
                    </h4>
                    <p class="pt-3">
                        Đội ngũ giáo viên ICFix trẻ trung, năng động đầy nhiệt huyết.<br>
                        Cung cấp các khóa học trực tuyến để sửa chữa iPhone, iPad, Watch...<br>
                        Được giáo viên truyền thụ võ công, lành tày nghề trước khi áp dụng vào thực tế sửa chữa cho máy khách.<br>
                        Bạn cũng có thể đăng ký làm giáo viên cho khóa học!<br>
                        Hãy đến với EduICFix!!!<br>
                        <br><br>

                        <a href="#all_course" class="btn btn-danger">Học ngày nào!</a>
                    </p>
                </div>
                <div class="col-6">
                    <iframe width="420" height="315" src="https://www.youtube.com/embed/vQ29aWBOB9Q">
                    </iframe>
                </div>
            </div>
        </div>
    </section>

    <section id="all_course" class="course-list mt-5">
        <div class="container">
            <section id="danh-sach-khoa-hoc">
                <h5 class="tieu_de">Danh sách khóa học</h5>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-5 mb-5">
                    <h5 class="alert alert-warning ml-5"><?php echo e($c->name); ?></h5>
                    <ul class="dskhoahoc d-flex flex-wrap">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($course->cat_id == $c->id): ?>
                        <li class="col-12 col-md-4 item_kh">
                            <div class="wrap">
                                <a href="javascript:void(0)" class="mb-3 text-center"><?php echo e($course->title); ?></a>
                                <div class="preview-pic tab-content">
                                    <div class="tab-pane active" id="pic-1"><img src="https://dummyimage.com/150x150/0099ff/000" /></div>
                                </div>
                                <div class="mo_ta_bai_hoc">
                                    <div class="mo-ta-ngan text-primary">Mô tả ngắn:</div>
                                    <div class="mo_ta_text"> <?php echo nl2br($course->summary); ?></div>

                                </div>
                                <div class="link col-12">
                                    <div class="row">
                                        <div class="price badge badge-success">
                                            <?php if($course->price == 0): ?>
                                            Miễn phí
                                            <?php else: ?>
                                            <?php echo e($course->price); ?> Xu
                                            <?php endif; ?>
                                        </div>
                                        <div class="detail badge badge-danger">
                                            <a href="<?php echo e(route('khoahoc', [ 'course_id' => $course->id])); ?>" class="">Mua</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </section>
        </div>
    </section>
    <section class="doi_ngu_giao_vien pt-3 pb-5">
        <div class="container">
            <h4 class="text-center text-danger">Đội ngũ giáo viên IC Fix</h4>
            <div class="row">
                <ul class="form-group teacher_list">
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="">
                        <?php echo e($teacher->name); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </section>

    <!-- <section class="doi_ngu_giao_vien">
        <div class="container">
            <div class="row">
                Đăng ký thành viên
            </div>
        </div>
    </section>
    <section class="lien_he">
        <div class="container">
            <div class="row">
                Đăng ký liên hệ
            </div>
        </div>
    </section> -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog/resources/views/top.blade.php ENDPATH**/ ?>