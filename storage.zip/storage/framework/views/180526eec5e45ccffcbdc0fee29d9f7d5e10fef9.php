<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Tiêu đề:</strong>
                <h4 class="text-danger"><?php echo e($ddcourse->dd_title); ?></h4>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">

            <strong class="">Link video</strong> <a href="<?php echo e($ddcourse->url); ?>" target="_blank" class="">:<?php echo e($ddcourse->url); ?></a>

        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 mt-4">
            <div class="mb-3"> <strong class="">Nội dung (Text + Hình ảnh)</strong></div>
            <div class="content"> <?php echo nl2br($ddcourse->body); ?></div>
        </div>
    </div>
</div>
<style>
    .content {
        border: 1px dotted black;
        padding: 50px 20px;
    }

    .content br {
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog/resources/views/admin/ddcourses/show.blade.php ENDPATH**/ ?>