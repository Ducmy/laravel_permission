<html lang="vn">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'I Can Fix')); ?></title>


    <?php $__env->startSection('head_css'); ?>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/common.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/css/index.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldSection(); ?>
    <?php echo $__env->yieldPushContent('css'); ?>


    <!-- Scripts -->
    <?php $__env->startSection('head_js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldSection(); ?>
    <?php echo $__env->yieldPushContent('js'); ?>
    <!-- Fonts -->

    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600&family=Noto+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Raleway:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600&display=swap" rel="stylesheet">
    <!-- Styles -->

</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    I Can FIX
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto"></ul>
                    <ul class="navbar-nav ml-auto">
                        <?php if(auth()->guard()->guest()): ?>
                        <li><a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Đăng nhập')); ?></a></li>
                        <li><a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Đăng ký')); ?></a></li>
                        <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a href="<?php echo e(route('my-account')); ?>" class="dropdown-item">Thông tin cá nhân</a>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <main class="py-4">
            <div class="container">
                <div class="row">
                    <div class="col-2">
                        <ul class="list-group">
                            <?php if(auth()->check() && auth()->user()->hasRole('super-admin|admin')): ?>
                            <li class="list-group-item"><a class="nav-link" href="<?php echo e(route('users.index')); ?>">Quản lý thành viên</a></li>
                            <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('super-admin|admin')): ?>
                            <li class="list-group-item"><a class="nav-link" href="<?php echo e(route('teachers.index')); ?>">Quản lý giáo viên</a></li>
                            <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('super-admin|admin|teacher')): ?>
                            <li class="list-group-item">
                                <a class="nav-link" href="<?php echo e(route('courses.index')); ?>">
                                    Quản lý khóa học
                                </a>

                                <div class="dropdown ml-5 mt-2">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Qlý chuyên mục
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="<?php echo e(route('index_cat')); ?>">Danh sách chuyên mục</a>
                                        <a class="dropdown-item" href="<?php echo e(route('create_cat')); ?>">Tạo mới</a>
                                    </div>
                                </div>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="col-10">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>

</html><?php /**PATH /var/www/html/blog/resources/views/layouts/admin.blade.php ENDPATH**/ ?>