<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('css/admin/index.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Quản lý khóa học</h2>
        </div>
        <div class="pull-right mb-3 float-right">
            <a class="btn btn-success" href="<?php echo e(route('courses.create')); ?>"> Tạo khóa học mới</a>
        </div>
    </div>
</div>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Tiêu đề</th>
        <th>Miêu tả</th>
        <th>Giá</th>
        <th width="280px">Thao tác</th>
    </tr>
    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($course->title); ?></td>
        <td> <div class=""> <?php echo nl2br($course->summary); ?></div></td>
        <td><?php echo e($course->price); ?></td>
        <td>
            <form action="<?php echo e(route('courses.destroy',$course->id)); ?>" method="POST">
                <a class="btn btn-info" href="<?php echo e(route('courses.show',$course->id)); ?>">Xem chi tiết</a>
                <a class="btn btn-primary" href="<?php echo e(route('courses.edit',$course->id)); ?>">Cập Nhật</a>
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Xóa</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $courses->links(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog/resources/views/courses/index.blade.php ENDPATH**/ ?>