<li class="list-group-item"><?php echo e($child_category->name); ?><span class="float-right"><a href="<?php echo e(route('edit_cat', ['cat_id'=> $child_category->id])); ?>" class="ml-auto btn btn-primary">Sửa</a><a href="" class="btn btn-danger ml-2">Xóa</a></span></li>
<?php if($child_category->categories): ?>
    <ul class="list-group ml-5">
        <?php $__currentLoopData = $child_category->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('admin.categories.subcategory', ['child_category' => $childCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?><?php /**PATH /var/www/html/blog/resources/views/admin/categories/subcategory.blade.php ENDPATH**/ ?>