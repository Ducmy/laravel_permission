<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-lg-12 margin-tb">
      <div class="pull-right mb-2">
        <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>">Tạo thành viên mới</a>
      </div>
    </div>
  </div>
  <?php if($message = Session::get('success')): ?>
  <div class="alert alert-success">
    <p><?php echo e($message); ?></p>
  </div>
  <?php endif; ?>

  <div class="row mt-4">
    <div class="col-lg-12 margin-tb d-flex justify-content-between">
      <a href="<?php echo e(url('admin/users')); ?>" class="btn btn-primary list_btn">Xem toàn bộ danh sách</a>
      <form action="<?php echo e(url('admin/users')); ?>" method="get" class="form-search-course d-flex">
        <div class="form-group">
          <input type="text" name="filter[email]" class="form-control" placeholder="Nhập emai,..." />
        </div>
        <button type="submit" class="btn btn-primary ml-3">Tìm kiếm</button>
      </form>
    </div>
  </div>

  <table class="table table-bordered">
    <tr>
      <th>No</th>
      <th>Họ tên</th>
      <th>Email</th>
      <th>Thành viên</th>
      <th width="280px">Thao tác</th>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e(++$i); ?></td>
      <td><?php echo e($user->name); ?></td>
      <td><?php echo e($user->email); ?></td>
      <td>
        <?php if(!empty($user->getRoleNames())): ?>
        <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($v == 'user'): ?>
        <?php endif; ?>
        <label class="badge badge-dark">
          <?php if($v == 'user'): ?>
          Học viên
          <?php elseif($v == 'teacher'): ?>
          Giáo viên
          <?php elseif($v == 'admin'): ?>
          Admin
          <?php elseif($v == 'super-admin'): ?>
          Super Admin
          <?php endif; ?>
        </label>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </td>
      <td>
        
        <a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id)); ?>">Cập nhật</a>
        <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

        <?php echo Form::submit('Xóa', ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <?php echo $data->render(); ?>

</div>

<style>

  .form-search-course .form-group {
    width: 400px;
    flex: 0 0 400px;
  }

  .btn:not(:disabled):not(.disabled) {
    margin-bottom: 1em;
  }

  .list_btn {
    height: 38px;
  }

</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog/resources/views/admin/users/index.blade.php ENDPATH**/ ?>