<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Chi tiết khóa học</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('courses.index')); ?>"> Quay lại</a>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Tiêu đề:</strong>
            <?php echo e($course->title); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Mô tả ngắn:</strong>
            <?php echo e($course->summary); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Giá:</strong>
            <?php echo e($course->price); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Giáo viên:</strong>
            <?php
                $teacher = App\User::find($course->teacher_id);
             ?>
            <?php echo e($teacher->name); ?>

        </div>
    </div>

    <form action="<?php echo e(route('my-account-buy')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <input type="hidden" name="course_id" class="form-control" value="<?php echo e($course->id); ?>">
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <?php if(auth()->guard()->check()): ?>
            <?php if($isPurchased): ?>
            <div class="badge badge-success">Bạn đã mua khóa học này</div>
            <div class="course-lists">
                Danh sách bài học
                <ul class="courses">
                    <?php $__currentLoopData = $ddcourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ddcourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($ddcourse->course_id == $course->id): ?>
                    <li>
                        <a href="<?php echo e(route('ddcourses.show',$ddcourse->id)); ?>"><?php echo e($ddcourse->dd_title); ?></a></li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php else: ?>
            <button type="submit" class="btn btn-primary">Mua khóa học</button>
            <?php endif; ?>
            <?php else: ?>
            <button type="submit" class="btn btn-primary">Mua khóa học</button>
            <?php endif; ?>
        </div>
    </form>


</div>
<div class="col-xs-12 col-sm-12 col-md-12">
    <h4>Phần bình luận</h4>
    <?php echo $__env->make('admin.courses.commentsDisplay', ['comments' => $course->comments, 'course_id' => $course->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <hr />
    <h4>Thêm bình luận</h4>
    <form method="post" action="<?php echo e(route('comments.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <textarea class="form-control" name="body"></textarea>
            <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>" />
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-success" value="Bình luận" />
        </div>
    </form>
</div>
<p class="text-center text-primary"><small>Develop by MyNguyen</small></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog/resources/views/admin/courses/show.blade.php ENDPATH**/ ?>