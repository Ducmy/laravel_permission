<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Quản lý khóa học</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-success" href="<?php echo e(route('courses.create')); ?>"> Tạo khóa học mới</a>
        </div>
    </div>
</div>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Tiêu đề</th>
        <th>Nội dung</th>
        <th width="280px">Thao tác</th>
    </tr>
    <?php $__currentLoopData = $ddcourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ddcourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($ddcourse->dd_title); ?></td>
        <td><?php echo e($ddcourse->body); ?></td>
        <td>
            <form action="<?php echo e(route('ddcourses.destroy',$ddcourse->id)); ?>" method="POST">
                <a class="btn btn-info" href="<?php echo e(route('ddcourses.show',$ddcourse->id)); ?>">Xem chi tiết</a>
                <a class="btn btn-primary" href="<?php echo e(route('ddcourses.edit',$ddcourse->id)); ?>">Cập Nhật</a>
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Xóa</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $ddcourses->links(); ?>

<p class="text-center text-primary"><small>Develop by MyNguyen</small></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog/resources/views/admin/ddcourses/index.blade.php ENDPATH**/ ?>