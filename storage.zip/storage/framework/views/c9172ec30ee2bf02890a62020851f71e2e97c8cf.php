<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('css/admin/index.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('admin/css/categories.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<h5 class="alert alert-info">Danh sách chuyên mục</h5>
<div class="cat_list">
<ul class="list-group">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item"><?php echo e($category->name); ?> <span class="float-right">
            
        <?php if($category->id !== 1): ?>
        <form action="<?php echo e(route('destroy_cat', ['cat_id'=> $category->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <a href="<?php echo e(route('edit_cat', ['cat_id'=> $category->id])); ?>" class="ml-auto btn btn-primary">Sửa</a>
        
  
            <button type="submit" class="btn btn-danger">Xóa</button>
        </form>
        </form>
        <?php endif; ?>
    </span></li>
        <ul class="list-group ml-5">
        <?php $__currentLoopData = $category->childrenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('admin.categories.subcategory', ['child_category' => $childCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog/resources/views/admin/categories/index.blade.php ENDPATH**/ ?>