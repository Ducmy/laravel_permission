<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="display-comment" <?php if($comment->parent_id != null): ?> style="margin-left:40px;" <?php endif; ?>>
        <strong><?php echo e($comment->user->name); ?></strong>
        <p><?php echo e($comment->body); ?></p>
        <form method="post" action="<?php echo e(route('comments.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" name="body" class="form-control" />
                <input type="hidden" name="lession_id" value="<?php echo e($ddcourse_id); ?>" />
                <input type="hidden" name="parent_id" value="<?php echo e($comment->id); ?>" />
            </div>
            <div class="form-group">
                <a href="javascript:void(none)" id="reply_<?php echo e($comment->id); ?>" class="traloi">Trả lời</a>
                <input type="submit" class="text-primary submit_btn" value="Gửi" />
            </div>
        </form>
        
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /var/www/html/blog/resources/views/khoahoc/commentsDisplay.blade.php ENDPATH**/ ?>