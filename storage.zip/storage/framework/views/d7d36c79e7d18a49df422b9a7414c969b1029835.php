<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('css/admin/index.css')); ?>" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-right mb-3 float-right">
            <a class="btn btn-success" href="<?php echo e(route('courses.create')); ?>"> Tạo khóa học mới</a>
        </div>
    </div>
</div>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Ảnh mô tả</th>
        <th>Tiêu đề</th>
        <th>Miêu tả</th>
        <th>Trạng thái</th>
        <th>Giá</th>
        <th width="280px">Thao tác</th>
    </tr>
    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <th>
            <img class="img-fluid img-thumbnail" src="<?php echo e(asset('images/not_found.png')); ?>" alt="<?php echo e($course->title); ?>">
        </th>
        <td><?php echo e($course->title); ?></td>
        <td>
            <div class=""> <?php echo nl2br($course->summary); ?></div>
        </td>
        <td>
            <input type="hidden" id="course_<?php echo e($course->id); ?>" name="id" value="<?php echo e($course->id); ?>">
            <input class="toggle" id="toggle-event-<?php echo e($course->id); ?>" type="checkbox" <?php if($course->active): ?>
            checked
            <?php endif; ?>
            data-toggle="toggle">


        </td>
        <td><?php echo e($course->price); ?></td>
        <td>
            <form action="<?php echo e(route('courses.destroy',$course->id)); ?>" method="POST">
                
                <a class="btn btn-primary" href="<?php echo e(route('courses.edit',$course->id)); ?>">Cập Nhật</a>
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Xóa</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $courses->links(); ?>

<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>
<script>
    $(function() {

        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        $('#toggle-event-<?php echo e($course->id); ?>').change(function(e) {
            var active = ($(this).prop('checked')) ? 1 : 0;
            var id = $("#course_<?php echo e($course->id); ?>").val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                }
            });
            e.preventDefault();
            var formData = {
                active,
                id,
            };
            var type = "POST";
            var ajaxurl = "<?php echo e(route('courseStatus', ['id' => $course->id])); ?>";

        $.ajax({
            type: type,
            url: ajaxurl,
            data: formData,
            dataType: 'json',
            success: function (data) {
                
            },
            error: function (data) {
                console.log(data);
            }
            });
        })
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog/resources/views/admin/courses/index.blade.php ENDPATH**/ ?>