<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('css/admin/index.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script src="/ckeditor/ckeditor.js"></script> 
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb mb-3">
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('courses.edit', $ddcourse->course_id)); ?>"> Quay lại</a>
        </div>
    </div>
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('ddcourses.update',$ddcourse->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Tên bài học</strong>
                <input type="text" name="dd_title" value="<?php echo e($ddcourse->dd_title); ?>" class="form-control" placeholder="Name">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nội dung</strong>
                <textarea id="editor1" class="form-control" name="body" cols="30" rows="10"><?php echo e($ddcourse->body); ?></textarea>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Link youtube</strong>
                <input type="text" name="url" value="<?php echo e($ddcourse->url); ?>" class="form-control" placeholder="URL">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Cập nhập bài học</button>
        </div>
    </div>
</form>

<script type="text/javascript">  
   CKEDITOR.replace( 'editor1' );  
</script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog/resources/views/admin/ddcourses/edit.blade.php ENDPATH**/ ?>